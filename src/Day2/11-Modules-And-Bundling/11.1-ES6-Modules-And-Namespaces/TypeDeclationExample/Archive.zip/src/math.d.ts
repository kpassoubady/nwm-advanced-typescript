export function add(a: any, b: any): any;
export function subtract(a: any, b: any): number;
export function multiply(a: any, b: any): number;
export function div(a: any, b: any): number;
